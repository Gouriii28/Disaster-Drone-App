# SAADAXA — Rescue Team Console

SAADAXA is the field app for the patented *Autonomous Aerial Disaster Assistance and Location Tracking System*.
It is used by **rescue teams**. Survivors use a separate, simple **SOS page**.

```
 Aerial units (drones) ──►  Ground server (your laptop)  ◄──►  Rescue team phones (SAADAXA app)
                                     ▲
                                     └──────────  Survivor phones (SOS page, no sign-in)
```

## What the rescue team app does

| Screen | What it does |
|---|---|
| **Operations** | Team status, position mode, network status, new cases waiting for a team, your team's cases, **disaster alerts for India only**, aerial units, operation log |
| **Map** | Real **satellite imagery with place names** (or street map). Shows cases, other teams, aircraft, hazards and India alert areas |
| **Cases** | Survivors found by aircraft plus SOS calls from survivors. **Accept → En route → On scene → Rescued.** Open a case to **message the survivor**: text or hold-to-talk voice |
| **Record** | Field video (live camera) and audio, stamped with time and position |
| **Assistant** | AI help for rescue teams: START triage, crush injuries, collapsed buildings, water rescue, and "which cases are critical and nearest to me?" Works offline too |
| **Settings** ⚙ | Sign out, automatic position status, connection, and the survivor SOS page link |

**How teams reach survivors:**
- **SOS calls:** your messages appear on the survivor's SOS page, and their replies come back into the case.
- **Survivors found by aircraft:** your text or voice message is queued for the drone that found them, which plays it on its **loudspeaker**. Survivor speech picked up by the drone's microphone appears in the case.

**Position is fully automatic**. There are no switches:

| Situation | What the app does |
|---|---|
| GPS signal available | Uses **GPS** (±5–20 m) |
| No GPS, but Wi-Fi / mobile network | Uses **Wi-Fi / network positioning** (±30–150 m) |
| Neither (indoors, rubble, no signal) | Switches to **GPS-denied mode**: keeps your last good position as an *anchor* and estimates your movement by counting steps and reading the compass. The ± error grows as you walk, and resets as soon as GPS returns (re-anchoring) |
| No position ever | Tap **Set position on map** |
| No network | Updates, messages and reports are saved on the phone and sent automatically when a connection returns |

**India-only disaster alerts** come from three sources, all shown only when they are in India:
- **NDMA SACHET**, the official Indian alert system, with the warning areas drawn on the map
- **GDACS**
- **USGS** earthquakes

---

## 1. Folder structure

```
saadaxa/
├── README.md
├── scripts/
│   ├── make_cert.py          # makes the HTTPS certificate (Windows, macOS, Linux)
│   └── make-cert.sh          # same, using openssl (macOS, Linux)
├── server/                   # ground server (Python)
│   ├── run.py                # START HERE
│   ├── main.py               # API: team sign-in, cases, messages, SOS, alerts, assistant
│   ├── store.py              # database (SQLite)
│   ├── simulator.py          # optional training simulator (2 synthetic drones)
│   ├── geo.py                # coordinate maths from the patent
│   ├── knowledge.py          # offline field guidance
│   ├── requirements.txt
│   ├── .env.example          # settings template
│   └── data/                 # created automatically (database, recordings, voice messages)
└── web/
    ├── index.html            # rescue team app
    ├── sos.html              # survivor SOS page (no sign-in)
    ├── css/  js/  icons/  vendor/leaflet/
    ├── manifest.webmanifest
    └── sw.js
```

---

## 2. Install on Windows (PowerShell) — first time

Run **one command per line**: PowerShell does not accept `&&`.

**2.1 Python.** Install Python 3.12 or 3.13 from https://www.python.org/downloads/windows/ and tick **"Add python.exe to PATH"**.

**2.2 Unzip** (`saadaxa.zip` must be in Downloads):
```powershell
cd $HOME\Downloads
Expand-Archive -Path .\saadaxa.zip -DestinationPath $HOME -Force
cd $HOME\saadaxa
```

**2.3 Python environment and packages:**
```powershell
py -3.13 -m venv .venv
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
.\.venv\Scripts\Activate.ps1
pip install -r server\requirements.txt
```

**2.4 Settings:**
```powershell
Copy-Item server\.env.example server\.env -Force
notepad server\.env
```
Change `TEAM_ACCESS_CODE=change-this-code` to your own code, for example `TEAM_ACCESS_CODE=ndrf-blr-2026`. Every team member types this code to sign in. Save with `Ctrl + S` and close Notepad.

**2.5 HTTPS certificate:**
```powershell
python scripts\make_cert.py
```
Note the `https://...:8443` address it prints.

**2.6 Allow phones through the firewall** (once). Open PowerShell **as Administrator** (Start → type PowerShell → right-click → Run as administrator) and run:
```powershell
New-NetFirewallRule -DisplayName "SAADAXA 8443" -Direction Inbound -Protocol TCP -LocalPort 8443 -Action Allow
```

## 2b. Updating from an older SAADAXA version (Windows)

```powershell
cd $HOME\Downloads
Expand-Archive -Path .\saadaxa.zip -DestinationPath $HOME -Force
cd $HOME\saadaxa
.\.venv\Scripts\Activate.ps1
pip install -r server\requirements.txt
Copy-Item server\.env.example server\.env -Force
notepad server\.env
```
Set your `TEAM_ACCESS_CODE` again (and your AI key, if you had one). The old database is moved to `server\data\saadaxa-v1-backup.db` automatically.

## 2c. Install on macOS / Linux

```bash
cd ~/Downloads && unzip -o saadaxa.zip -d ~/ && cd ~/saadaxa
python3 -m venv .venv && source .venv/bin/activate
pip install -r server/requirements.txt
cp server/.env.example server/.env && nano server/.env
python3 scripts/make_cert.py
```

---

## 3. Run (every time)

**Windows:**
```powershell
cd $HOME\saadaxa
.\.venv\Scripts\Activate.ps1
python server\run.py
```
**macOS / Linux:**
```bash
cd ~/saadaxa && source .venv/bin/activate && python3 server/run.py
```

Wait for the line `Uvicorn running on https://0.0.0.0:8443`. Keep the window open. `Ctrl + C` stops the server.

### Open the app
| Who | Address | Notes |
|---|---|---|
| Rescue team, on the laptop | `https://localhost:8443` | |
| Rescue team, on a phone | `https://<laptop IP>:8443` (printed by `make_cert.py`) | Phone on the **same Wi-Fi** as the laptop |
| Survivors | `https://<laptop IP>:8443/sos.html` | No sign-in. Also shown in Settings → *Survivor SOS page* |

At the "Your connection is not private" warning, tap **Advanced → Proceed**. If there is no Proceed link, click the page and type `thisisunsafe`. This happens because the certificate was made on your laptop. The connection is still encrypted.

Allow **location**, **camera**, **microphone** and (on iPhone) **motion sensors** when asked.

**Install as an app:** Chrome ⋮ → *Add to Home screen* (Android) · Safari Share → *Add to Home Screen* (iPhone).

### Sign in
Team name (e.g. `Team 3`), your name or call sign, and the **access code** from `server\.env`.

---

## 4. Settings file (`server\.env`)

| Setting | Meaning |
|---|---|
| `TEAM_ACCESS_CODE` | Code teams type to sign in. **Change it** |
| `OPERATION_NAME` | Name shown at the top |
| `CENTER_LAT`, `CENTER_LON` | Where the map opens before a position is known (default: centre of India) |
| `SIMULATION` | `0` = live data only (default). `1` = training mode with 2 synthetic drones near `CENTER_LAT/LON`, clearly labelled in the app |
| `ANTHROPIC_API_KEY` | Optional AI assistant key (see below). Empty = built-in offline field guidance |
| `ALERTS_ENGLISH_ONLY` | `0` (default) = show every India alert; ones with no English version show in their own language (e.g. Bengali from West Bengal) with a language label. With an AI key, they are translated to English automatically. `1` = hide alerts that have no English version |
| `DRONE_TOKEN` | Optional secret that drones must send |

**AI key (optional):**
1. Go to https://console.anthropic.com and sign up.
2. Add billing under Settings → Billing.
3. Go to https://console.anthropic.com/settings/keys → **Create Key** → copy it (it starts with `sk-ant-`).
4. Put it in `server\.env` as `ANTHROPIC_API_KEY=sk-ant-...` and restart the server.

---

## 5. Connecting real drones

The drone's onboard computer talks to the server over HTTP. The examples below use curl.

**Telemetry** (2–10 times a second):
```bash
curl -k -X POST https://<laptop IP>:8443/api/drone/telemetry -H "Content-Type: application/json" \
  -d '{"drone_id":"UAV-01","lat":12.9716,"lon":77.5946,"alt":30,"battery":87,"hdop":1.2,
       "nav_mode":"GNSS","rssi":-61,"link":"WIFI","state":"SURVEY"}'
```
`nav_mode` must be one of `GNSS`, `DEGRADED`, `VIO`, `POS_HOLD`, `REACQ`. `link` must be `WIFI` or `LORA`.

**Survivor detection.** Detections within 3 m of each other are merged into one case:
```bash
curl -k -X POST https://<laptop IP>:8443/api/drone/detection -H "Content-Type: application/json" \
  -d '{"drone_id":"UAV-01","lat":12.97181,"lon":77.59472,"confidence":0.87,"thermal":true}'
```

**Messages to play on the loudspeaker.** Poll every few seconds:
```bash
curl -k https://<laptop IP>:8443/api/drone/UAV-01/outbox
```
Each item has `text` (speak it with text-to-speech) and/or `audio_url` (download and play it). After playing, confirm:
```bash
curl -k -X POST https://<laptop IP>:8443/api/drone/ack -H "Content-Type: application/json" \
  -d '{"message_id":12,"status":"played","drone_id":"UAV-01"}'
```

**Survivor speech from the drone microphone:**
```bash
curl -k -X POST https://<laptop IP>:8443/api/drone/audio -F survivor_id=SV-ABC123 -F drone_id=UAV-01 -F file=@clip.webm;type=audio/webm
```

If `DRONE_TOKEN` is set, add `-H "X-Drone-Token: <token>"` to every drone request.

---

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| `Uvicorn running` line does not appear | Scroll to the **last** red line and read the error. `No module named ...`: run `pip install -r server\requirements.txt` with `(.venv)` active |
| Phone: "site can't be reached" / "refused to connect" | Check: the server window is open · the address has `https://` and `:8443` · the firewall rule from 2.6 is added · phone and laptop are on the same Wi-Fi. College Wi-Fi often blocks devices from reaching each other. Use the phone's hotspot instead, then run `python scripts\make_cert.py` again and restart the server |
| Laptop IP address changed | Run `python scripts\make_cert.py`, then restart the server |
| "Wrong access code" | Use the exact `TEAM_ACCESS_CODE` from `server\.env`. Restart the server after editing it |
| Camera, microphone or location do nothing | You must use the `https://` address |
| Map is grey | The device has no internet, or the network blocks the map servers (common on college Wi-Fi). The app tells you on the map. Use mobile data or a phone hotspot. Test on the device: open https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/5/14/22 — you should see a satellite picture of part of India |
| "Alert feeds unreachable" | The laptop running the server has no internet |
| Always shows GPS-denied indoors | That is expected without sky view. It returns to GPS automatically outside |
| Start completely fresh | Stop the server, then run `Remove-Item -Recurse -Force server\data` and start it again |

Emergency numbers used in the app (India): 112 all emergencies · 108 ambulance · 101 fire · 100 police · 1078 disaster helpline.
