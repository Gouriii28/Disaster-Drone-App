#!/usr/bin/env bash
# Creates a self-signed HTTPS certificate for SAADAXA so phones on the same
# Wi-Fi can use the camera, microphone and GPS.
# Usage (from the project root):  bash scripts/make-cert.sh
set -e
cd "$(dirname "$0")/.."
mkdir -p certs

# Find this computer's LAN IP address (Linux first, then macOS)
IP=$(hostname -I 2>/dev/null | awk '{print $1}')
if [ -z "$IP" ]; then IP=$(ipconfig getifaddr en0 2>/dev/null || true); fi
if [ -z "$IP" ]; then IP=127.0.0.1; fi

openssl req -x509 -newkey rsa:2048 -nodes -days 365 \
  -keyout certs/key.pem -out certs/cert.pem \
  -subj "/CN=SAADAXA Local Server" \
  -addext "subjectAltName=DNS:localhost,IP:127.0.0.1,IP:${IP}"

echo ""
echo "Certificate created in certs/"
echo "Open this on your phone (same Wi-Fi):  https://${IP}:8443"
echo "Your phone will warn that the certificate is not trusted — tap Advanced → Proceed."
