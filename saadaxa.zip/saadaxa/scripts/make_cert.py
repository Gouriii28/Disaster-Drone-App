"""
Creates a self-signed HTTPS certificate for SAADAXA so phones on the same
Wi-Fi can use the camera, microphone and GPS.

Works on Windows, macOS and Linux (no openssl needed).

Usage (from the saadaxa folder, with the virtual environment active):
    python scripts/make_cert.py
"""
import datetime
import ipaddress
import socket
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


def lan_ip() -> str:
    """Find this computer's Wi-Fi / LAN address (no data is actually sent)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def main():
    root = Path(__file__).resolve().parent.parent
    out = root / "certs"
    out.mkdir(exist_ok=True)
    ip = lan_ip()

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "SAADAXA Local Server")])
    now = datetime.datetime.now(datetime.timezone.utc)
    san = x509.SubjectAlternativeName([
        x509.DNSName("localhost"),
        x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
        x509.IPAddress(ipaddress.ip_address(ip)),
    ])
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(minutes=5))
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(san, critical=False)
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .sign(key, hashes.SHA256())
    )

    (out / "key.pem").write_bytes(key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption(),
    ))
    (out / "cert.pem").write_bytes(cert.public_bytes(serialization.Encoding.PEM))

    print("Certificate created in certs\\ (certs/)")
    print(f"Open this on your phone (same Wi-Fi):  https://{ip}:8443")
    print("Your phone will warn that the certificate is not trusted - tap Advanced -> Proceed.")


if __name__ == "__main__":
    main()
